<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Cura_Testsuites_MakeAppointment_002_testdata</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>ccaa54d1-c0ee-4467-861c-c846fe9edd1f</testSuiteGuid>
   <testCaseLink>
      <guid>8f57d0ce-b48f-4b61-bad0-ae53d371c443</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <iterationNameVariable>
         <defaultValue>''</defaultValue>
         <description></description>
         <id>6ee32555-4261-4a00-ab5a-c2624b5f6320</id>
         <masked>false</masked>
         <name>isRegex</name>
      </iterationNameVariable>
      <testCaseId>Test Cases/TC_CURA_MakeAppointment_002</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
